export const BACKEND_URI = 'test';
